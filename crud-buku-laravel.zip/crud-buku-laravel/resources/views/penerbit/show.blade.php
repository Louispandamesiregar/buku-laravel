@include('layout.header')
        <h3>Detail Kategori</h3>
        <table>
            
            <tbody>
                <tr>
                    <td width="150px">Nama Kategori</td>
                    <td width="2px">:</td>
                    <td>{{ $penerbit->nama_penerbit }}</td>
                </tr>
                
            </tbody>
        </table>
@include('layout.footer')
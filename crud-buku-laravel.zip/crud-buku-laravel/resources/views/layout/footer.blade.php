<div class="footer">&copy; 2025 Laravel Web Team 2</div>
    </div>
</body>
</html>
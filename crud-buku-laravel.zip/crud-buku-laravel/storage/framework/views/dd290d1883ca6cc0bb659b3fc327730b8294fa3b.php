<div class="footer">&copy; 2025 Laravel Web Team 2</div>
    </div>
</body>
</html><?php /**PATH C:\xamppnew\htdocs\crud-buku-laravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>
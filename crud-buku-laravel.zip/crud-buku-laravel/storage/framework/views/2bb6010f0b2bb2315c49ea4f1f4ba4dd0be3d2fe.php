<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h3>Buat Kategori</h3>
        <form action="<?php echo e(route('kategori.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Nama Kategori:</label>
                <input type="text" name="nama_kategori" id="" placeholder="Masukan Nama Kategori">
            </div>
            <button type="submit" class="tombol">Submit</button>
        </form>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\crud-buku-laravel\resources\views/kategori/create.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Detail Buku</h3>
<table>
    <tbody>
        <tr>
            <td style="width: 150px; font-weight: 600;">Judul Buku</td>
            <td style="width: 10px;">:</td>
            <td><?php echo e($buku->judul); ?></td>
        </tr>
        <tr>
            <td style="font-weight: 600;">Pengarang</td>
            <td>:</td>
            <td><?php echo e($buku->pengarang); ?></td>
        </tr>
        <tr>
            <td style="font-weight: 600;">Tahun Terbit</td>
            <td>:</td>
            <td><?php echo e($buku->tahun_terbit); ?></td>
        </tr>
        <tr>
            <td style="font-weight: 600;">Penerbit</td>
            <td>:</td>
            <td><?php echo e($buku->penerbit->nama_penerbit); ?></td>
        </tr>
        <tr>
            <td style="font-weight: 600;">Kategori</td>
            <td>:</td>
            <td><?php echo e($buku->kategori->nama_kategori); ?></td>
        </tr>
    </tbody>
</table>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xamppnew\htdocs\crud-buku-laravel\resources\views/buku/show.blade.php ENDPATH**/ ?>